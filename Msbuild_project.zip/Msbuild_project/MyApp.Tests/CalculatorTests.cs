using System;
using MyApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyApp.Tests
{
    [TestClass]
    public class CalculatorTests
    {
        private Calculator _calc;

        [TestInitialize]
        public void Init()
        {
            _calc = new Calculator();
        }

        [TestMethod]
        public void Add_ShouldReturnCorrectSum()
        {
            Assert.AreEqual(30, _calc.Add(10, 20));
        }

        [TestMethod]
        public void Divide_ShouldReturnCorrectValue()
        {
            Assert.AreEqual(5, _calc.Divide(10, 2));
        }

        [TestMethod]
        public void Divide_ByZero_ShouldThrowException()
        {
            Assert.ThrowsException<DivideByZeroException>(() => _calc.Divide(10, 0));
        }
    }
}
